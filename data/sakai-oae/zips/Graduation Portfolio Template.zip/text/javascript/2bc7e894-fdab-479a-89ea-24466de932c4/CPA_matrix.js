// <![CDATA[


function switchOn(contents) {

  // Pass it a contents ID, single-quoted:
  // switchOn('contents1')

  // Sets all contents (pages) to inactive state, then
  // activates the contents passed as parameters

  switchAllOff();
//  document.getElementById(tab).className = 'selectedtab';
  document.getElementById(contents).className = 'selectedcontents';
}





function clearTop() {

  // Sets all tabs to inactive state. Depends on the TR
  // enclosing the tabs having ID "toprow"

//  topRow = document.getElementById('toprow');
//  tabArray = topRow.childNodes;
//  for (var i=0; i<tabArray.length; i++) {
//    if (tabArray[i].className != 'tabspacer') {
//      tabArray[i].className = 'tab';
//    }
//  }
}

function clearContents() {

  // Hides all DIVs in TD ID="contentscell"

  contentsCell = document.getElementById('contentscell');
  contentsArray = contentsCell.childNodes;
  for (var j=0; j<contentsArray.length; j++) {
    contentsArray[j].className = 'contents';
  }
}

function switchAllOff() {

  // Trivial little wrapper function; sets all tabs and
  // contents to inactive/invisible state

//  clearTop();
  clearContents();
}

function setContent(content) {
 alert("DIV id is " + content );
  cont = content;
}


function switchOnContent() {

	alert("CONT = " + document.getElementById('previousDIV').value);
	switchOn(document.getElementById('previousDIV').value);
}



function previousContent() {

  // Hides all DIVs in TD ID="contentscell"
alert("Hello");
  contentsCell = document.getElementById('contentscell');
  contentsArray = contentsCell.childNodes;
  for (var n=0; n<contentsArray.length; n++) 
	{
		if (contentsArray[n].className == 'contents')
		 alert("NNN is " + n );

		//return n;
  	}
//return contents1;
}


function openContentIs3() {

var myArray = new Array("contents3", "contents4", "contents5")


alert("Test " + myArray[1]);

for (var n=0; n<myArray.length; n++) 
{
 		if (document.getElementById(myArray[n]).className != "contents");
	{
		alert("document " + document.getElementById(myArray[n]).className);
		alert("open content is " + myArray[n]);
		cont = myArray[n];
	}
}
//return contents1;
}






// ]]>
