To run scripts "5_build_general_education_matrix.html", "6_edit_all_matrix_cells.html" turn off Adblock Plus.


