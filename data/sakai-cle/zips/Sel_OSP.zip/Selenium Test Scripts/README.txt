To run scripts "2_build_four_matrix_forms.html", "7_add_glossary_terms_test.html" turn on Adblock Plus.

To run scripts "5_build_general_education_matrix.html", "6_edit_all_matrix_cells.html" turn off Adblock Plus.


